""" import pandas as pd
import matplotlib.pyplot as plt

# Load the data from the CSV file
# Make sure the CSV file is in the same directory as the script,
# or provide the full path to the file.
df = pd.read_csv('/home/jannen/Documents/MAS2025/Sem_2/SEE/Lect02/assignment02/my_group/manual_experiment.csv')

# Create a scatter plot
plt.figure(figsize=(10, 10))
plt.scatter(df['x'], df['y'], alpha=0.6)

# Style the plot
plt.grid(True, linestyle='--', alpha=0.5)
plt.xlabel("X [cm]", fontsize=12)
plt.ylabel("Y [cm]", fontsize=12)
plt.title("Scatter Plot of Manual Measurement Data", fontsize=13)
plt.axis('equal')
plt.tight_layout()

# Save the plot to a file
# plt.savefig('scatter_plot.png')

# To display the plot in a notebook or interactive environment, you would use:
plt.show() """


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load the data from the CSV file.
# Make sure your file has the columns: 'x', 'y', and 'orientation'.
try:
    df = pd.read_csv('/home/jannen/Documents/MAS2025/Sem_2/SEE/Lect02/assignment02/my_group/manual_experiment.csv')
except FileNotFoundError:
    print("Error: Make sure your CSV file is named 'your_data_with_orientation.csv' and is in the same folder.")
    exit()

# plot
plt.figure(figsize=(12, 12))

# Plot the points themselves
plt.scatter(df['x'], df['y'], alpha=0.5, s=50, label='Measured Position')

# Add an orientation arrow for each point
arrow_len = 0.7  # You can adjust the length of the arrows

for index, row in df.iterrows():
    # Get the x, y, and orientation (theta) for each row
    x = row['x']
    y = row['y']
    theta = row['orientation']

    # Calculate the arrow's change in x and y based on the angle
    dx = arrow_len * np.cos(theta)
    dy = arrow_len * np.sin(theta)

    plt.arrow(
        x, y, dx, dy,
        head_width=0.3,     # Adjust size of arrowhead
        head_length=0.3,    # Adjust size of arrowhead
        fc='red',           # Arrow color
        ec='red',
        alpha=0.8
    )

# visualize
plt.grid(True, linestyle='--', alpha=0.5)
plt.xlabel("X [cm]", fontsize=12)
plt.ylabel("Y [cm]", fontsize=12)
plt.title("Manual Measurements with Position and Orientation", fontsize=14)
plt.axis('equal')
plt.legend()
plt.tight_layout()

# Save the plot to a file
plt.savefig('scatter_plot_with_orientation.png')

plt.show()